<?php 
//posme:2023-02-27
namespace App\Models;
use CodeIgniter\Model;

class Fixed_Assent_Model extends Model  {
   function __construct(){		
      parent::__construct();
   }
   function update_app_posme($companyID,$branchID,$fixedAssentID,$data){
		$db 	= db_connect();
		$builder	= $db->table("tb_fixed_assent");
		
		$builder->where("companyID",$companyID);
		$builder->where("fixedAssentID",$fixedAssentID);	
		return $builder->update($data);
		
   }
   function delete_app_posme($companyID,$branchID,$fixedAssentID){
		$db 	= db_connect();
		$builder	= $db->table("tb_fixed_assent");		  		
		$data["isActive"]	= 0;
		
		$builder->where("companyID",$companyID);
		$builder->where("fixedAssentID",$fixedAssentID);	
		return $builder->update($data);
		
   } 
   function insert_app_posme($data){
		$db 			= db_connect();
		$builder		= $db->table("tb_fixed_assent");
		$result			= $builder->insert($data);
		$autoIncrement	= $db->insertID(); 		
		return $autoIncrement;
		
   }
   function get_rowByPK($companyID,$branchID,$fixedAssentID){
		$db 	= db_connect();
		$builder	= $db->table("tb_fixed_assent");    
		
		$sql = "";
		$sql = sprintf("select companyID, branchID, fixedAssentID, fixedAssentCode, name, description, modelNumber, marca, colorID, chasisNumber, reference1, reference2, year, asignedEmployeeID, categoryID, typeID, typeDepresiationID, yearOfUtility, currencyID, priceStart, isForaneo, statusID, createdIn, createdOn, createdAt, createdBy, countryID, cityID, municipalityID, address, areaID, projectID, duration, typeFixedAssentID, startOn, ratio, settlementAmount, currentAmount, isActive");
		$sql = $sql.sprintf(" from tb_fixed_assent i");		
		$sql = $sql.sprintf(" where i.companyID = $companyID");
		$sql = $sql.sprintf(" and i.fixedAssentID = $fixedAssentID");
		$sql = $sql.sprintf(" and i.isActive = 1");
		
		//Ejecutar Consulta
		return $db->query($sql)->getRow();
   }

   	function get_rowByPKListID($companyID,$branchID,$fixedAssetIDList){
		$db 		= db_connect();
		$builder	= $db->table("tb_fixed_assent");
		
		$query		= $builder->select('
			companyID, 
			branchID, 
			fixedAssentID, 
			fixedAssentCode, 
			name, 
			description, 
			modelNumber, 
			marca, 
			colorID, 
			chasisNumber, 
			reference1, 
			reference2, 
			year, 
			asignedEmployeeID, 
			categoryID, 
			typeID, 
			typeDepresiationID, 
			yearOfUtility, 
			currencyID, 
			priceStart, 
			isForaneo, 
			statusID, 
			createdIn, 
			createdOn, 
			createdAt, 
			createdBy, 
			countryID, 
			cityID, 
			municipalityID, 
			address, 
			areaID, 
			projectID, 
			duration, 
			typeFixedAssentID, 
			startOn, 
			ratio, 
			settlementAmount, 
			currentAmount, 
			isActive'
		);
			
		$query		= $query->where(['companyID'=>$companyID,'isActive'=>1]);
		$query		= $query->whereIn('fixedAssentID',$fixedAssetIDList);

		//Ejecutar consulta
		return $query->get()->getResultArray();
	}

}
?>