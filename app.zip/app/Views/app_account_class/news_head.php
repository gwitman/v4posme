				<div id="heading" class="page-header">
							<h1><i class="icon20  i-direction"></i> Agregar Centro de Costo</h1>
				</div> 