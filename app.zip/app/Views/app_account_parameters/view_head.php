				<div id="heading" class="page-header">
							<h1><i class="icon20  i-tools"></i> Configuracion de Parametros Contables</h1>
				</div> 