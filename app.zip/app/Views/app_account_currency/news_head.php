				<div id="heading" class="page-header">
							<h1><i class="icon20  i-coins"></i> Agregar Moneda</h1>
				</div> 