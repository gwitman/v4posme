				<div id="heading" class="page-header">
							<h1><i class="icon20  i-coins"></i> Editar Moneda</h1>
				</div> 