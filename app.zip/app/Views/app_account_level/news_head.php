				<div id="heading" class="page-header">
							<h1><i class="icon20  i-stairs"></i> Agregar Nivel de Cuentas</h1>
				</div> 