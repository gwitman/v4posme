				<div id="heading" class="page-header">
							<h1><i class="icon20  i-dice"></i> Agregar Indicador</h1>
				</div> 