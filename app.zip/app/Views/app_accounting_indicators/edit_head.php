				<div id="heading" class="page-header">
							<h1><i class="icon20  i-dice"></i> Editar Indicador</h1>
				</div> 