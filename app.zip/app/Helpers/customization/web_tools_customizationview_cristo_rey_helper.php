<?php

function getBehavioCristoRey(): array
{
    return array(
		strtolower('cristo_rey_app_invoice_billing_javaScriptShowCodeBarra')			=> "true"	
    );
}

?>
