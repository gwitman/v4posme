<?php

function getBehavioAguaTisey(): array
{
    
    return array(
		strtolower('tisey_app_invoice_billing_txtTraductionPhone')			=> "Facturador"	,
		strtolower('tisey_app_invoice_billing_divHiddenEmployer')			=> "hidden"		
		
		
    );
}

?>
