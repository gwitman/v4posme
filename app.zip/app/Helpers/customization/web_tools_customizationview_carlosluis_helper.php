<?php

function getBehavioCarlosLuis(): array
{
    return array(
		strtolower('carlosluis_app_box_share_btnVerMovimientos')         => "",
    );
}

?>
