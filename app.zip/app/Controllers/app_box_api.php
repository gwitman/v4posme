<?php
//posme:2023-02-27
namespace App\Controllers;
class app_box_api extends _BaseController {
	
    
	
	
}
?>